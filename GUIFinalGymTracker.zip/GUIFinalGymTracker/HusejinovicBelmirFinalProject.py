import tkinter as tk

class GymTracker:
    def __init__(self, master):
        self.master = master
        self.master.title("GymTracker")

        # create frames
        self.home_frame = tk.Frame(self.master)
        self.add_workout_frame = tk.Frame(self.master)
        self.about_frame = tk.Frame(self.master)
        self.history_frame = tk.Frame(self.master)
        
        # create widgets for home frame
        self.home_label = tk.Label(self.home_frame, text="Welcome to GymTracker!")
        self.name_label = tk.Label(self.home_frame, text="Enter your name:")
        self.name_entry = tk.Entry(self.home_frame)
        self.add_workout_button = tk.Button(self.home_frame, text="Add Workout", command=self.show_add_workout)
        self.view_history_button = tk.Button(self.home_frame, text="View History", command=self.show_history)
        self.about_button = tk.Button(self.home_frame, text="About", command=self.show_about)

        # create widgets for add workout frame
        self.add_workout_label = tk.Label(self.add_workout_frame, text="Add a New Workout")
        self.exercise_label = tk.Label(self.add_workout_frame, text="Exercise:")
        self.exercise_entry = tk.Entry(self.add_workout_frame)
        self.reps_label = tk.Label(self.add_workout_frame, text="Reps:")
        self.reps_entry = tk.Entry(self.add_workout_frame)
        self.sets_label = tk.Label(self.add_workout_frame, text="Sets:")
        self.sets_entry = tk.Entry(self.add_workout_frame)
        self.save_workout_button = tk.Button(self.add_workout_frame, text="Save", command=self.save_workout)

        # create widgets for about frame
        self.about_label = tk.Label(self.about_frame, text="About GymTracker")
        self.about_text = tk.Label(self.about_frame, text="GymTracker is a powerful and user-friendly application designed to help gym-goers track their workouts and fitness progress.")
        self.about_back_button = tk.Button(self.about_frame, text="Go back to main screen", command=self.show_home)

        # create widgets for history frame
        self.history_label = tk.Label(self.history_frame, text="Workout History")
        self.history_text = tk.Label(self.history_frame, text="No workout history to display.")
        self.history_back_button = tk.Button(self.history_frame, text="Go back to main screen", command=self.show_home)
        
        # layout widgets
        self.home_label.pack()
        self.name_label.pack()
        self.name_entry.pack()
        self.add_workout_button.pack()
        self.view_history_button.pack()
        self.about_button.pack()

        self.add_workout_label.pack()
        self.exercise_label.pack()
        self.exercise_entry.pack()
        self.reps_label.pack()
        self.reps_entry.pack()
        self.sets_label.pack()
        self.sets_entry.pack()
        self.save_workout_button.pack()

        self.about_label.pack()
        self.about_text.pack()
        self.about_back_button.pack()

        self.history_label.pack()
        self.history_text.pack()
        self.history_back_button.pack()

        # hide other frames
        self.add_workout_frame.pack_forget()
        self.about_frame.pack_forget()
        self.history_frame.pack_forget()

        # show home frame
        self.home_frame.pack()

    def show_add_workout(self):
        self.home_frame.pack_forget()
        self.add_workout_frame.pack()
        self.about_frame
        self.about_frame.pack_forget()
        self.history_frame.pack_forget()

    def show_history(self):
        self.home_frame.pack_forget()
        self.add_workout_frame.pack_forget()
        self.about_frame.pack_forget()
        self.history_frame.pack()
        self.history_text.configure(text="No workout history to display.") # update text with workout history data

    def show_home(self):
        self.home_frame.pack()
        self.add_workout_frame.pack_forget()
        self.about_frame.pack_forget()
        self.history_frame.pack_forget()

    def show_about(self):
        self.home_frame.pack_forget()
        self.add_workout_frame.pack_forget()
        self.about_frame.pack()
        self.history_frame.pack_forget()

    def save_workout(self):
        # save workout details to a database or file
        print(f"Exercise: {self.exercise_entry.get()}, Reps: {self.reps_entry.get()}, Sets: {self.sets_entry.get()}")
        # clear input fields
        self.exercise_entry.delete(0, tk.END)
        self.reps_entry.delete(0, tk.END)
        self.sets_entry.delete(0, tk.END)
        # switch back to home frame
        self.add_workout_frame.pack_forget()
        self.home_frame.pack()

# create the main window
root = tk.Tk()
app = GymTracker(root)
root.mainloop()
